package com.example.musicplayercs_1061461048;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.nio.file.Path;

public class MainActivity extends AppCompatActivity {
     private ImageView imgFront,imgStop,imgPlay,imgPause,imgNext,imgEnd;
     private ListView lstMusic;
     private TextView txtMusic;
     private MediaPlayer mediaplayer;
    ArrayAdapter<String> adaSong;
     private final String SONGPATH=new String("/sdcard/");
     String[] songname=new String[]{"greensleeves","mario","songbird","summersong","tradewinds"};
     String[] songfile=new String[]{"greensleeves.mp3","mario.mp3","songbird.mp3","summersong.mp3","tradewinds.mp3"};
     private int cListItem=0;
     private Boolean falgPause=false;
    private View.OnClickListener listener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {

            switch (v.getId()) {
                case R.id.imgFront:
                    frontSong();
                    break;
                case R.id.imgStop:
                    if (mediaplayer.isPlaying()) {
                        mediaplayer.reset();
                    }
                    break;

                case R.id.imgPlay:
                    if (falgPause) {
                        mediaplayer.start();
                        falgPause = false;
                    } else
                        playSong(SONGPATH+songfile[cListItem]);
                    break;
                case R.id.imgPause:
                    mediaplayer.pause();
                    falgPause = true;
                    break;
                case R.id.imgNext:
                    nextSong();
                    break;
                case R.id.imgEnd:
                    mediaplayer.release();
                    finish();
                    break;
             }
        }
    };
    private AdapterView.OnItemClickListener lstListener= new AdapterView.OnItemClickListener(){
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            cListItem=position;
            playSong(SONGPATH+ songfile[cListItem]);
        }
    };


    private void playSong(String path) {
        try
        {
            mediaplayer.reset();
            mediaplayer.setDataSource(path); //
            mediaplayer.prepare();
            mediaplayer.start(); //
            txtMusic.setText("歌曲名稱" + songname[cListItem]); //
            mediaplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer mp) {
                    nextSong(); //
                }
            });
        } catch (IOException e) {}
    }
    //
    private void nextSong() {
        cListItem++;
        if (cListItem >= lstMusic.getCount()) //
            cListItem = 0;
        playSong(SONGPATH + songfile[cListItem]);
    }
    //
    private void frontSong() {
        cListItem--;
        if (cListItem < 0)
            cListItem = lstMusic.getCount()-1; //
        playSong(SONGPATH + songfile[cListItem]);
    }

    private void requestStoragePermission() {
        if(Build.VERSION.SDK_INT >= 23) {  //Androis 6.0 以上
            //判斷是否已取得驗證
            int hasPermission = checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            if(hasPermission != PackageManager.PERMISSION_GRANTED) {  //未取得驗證
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                return;
            }
        }
        lstMusic.setAdapter(adaSong);  //已取得驗證
    }

    //requestPermissions 觸發的事件

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgFront= findViewById(R.id.imgFront);
        imgStop= findViewById(R.id.imgStop);
        imgPlay= findViewById(R.id.imgPlay);
        imgPause= findViewById(R.id.imgPause);
        imgNext= findViewById(R.id.imgNext);
        imgEnd= findViewById(R.id.imgEnd);
        lstMusic= findViewById(R.id.lstMusic);
        txtMusic=findViewById(R.id.txtMusic);
        imgFront.setOnClickListener(listener);
        imgStop.setOnClickListener(listener);
        imgPlay.setOnClickListener(listener);
        imgPause.setOnClickListener(listener);
        imgNext.setOnClickListener(listener);
        imgEnd.setOnClickListener(listener);
        lstMusic.setOnItemClickListener(lstListener);
        mediaplayer=new MediaPlayer();
        adaSong=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, songname);
        lstMusic.setAdapter(adaSong);
        requestStoragePermission();
    }
}








