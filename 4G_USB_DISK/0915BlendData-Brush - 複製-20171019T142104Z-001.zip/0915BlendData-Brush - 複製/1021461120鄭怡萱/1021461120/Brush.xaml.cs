﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace _021461120
{
    public partial class Brush : Page
    {
        public Brush()
        {
            InitializeComponent();
        }

        // 在使用者導覽至此頁面時執行。
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }
    }
}
