package com.example.spinner_1061461048;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView txtResult;
    private Spinner spnRefer;
    String[] Balls=new String[]{"棒球","足球","籃球","羽毛球","乒乓球"};
    private AdapterView.OnItemSelectedListener spnReferListener=new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String sel="最喜歡的運動為:" +adapterView.getSelectedItem().toString();
            txtResult.setText(sel);
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtResult=(TextView)findViewById(R.id.textResult);
        spnRefer=(Spinner)findViewById(R.id.spnPrefer);

        ArrayAdapter<String> adapterBalls=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,Balls);
        spnRefer.setAdapter(adapterBalls);
        spnRefer.setOnItemSelectedListener(spnReferListener);
    }
}
