package com.example.musicplayer_1061461048;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private ImageView imgFront,imgStop,imgPlay,imgPause,imgNext,imgEnd;
    private  ListView  lstMusic;
    private  TextView txtMusic;
    public  MediaPlayer mediaplayer;

   String[] songname=new String[]{"greensleeves","mario","songbird","summersong","tradewinds"};
    int[] songfile=new int[]{R.raw.greensleeves,R.raw.mario,R.raw.songbird,R.raw.summersong,R.raw.tradewinds};
   private int cListItem=0;
   private Boolean falgPause=false;
    private View.OnClickListener listener=new View.OnClickListener(){
        @Override
        public void onClick(View view) {


            switch (view.getId()) {
                case R.id.imgFront:
                    frontSong();
                    break;
                case R.id.imgStop:
                    if (mediaplayer.isPlaying()) {
                        mediaplayer.reset();
                    }
                    break;

                case R.id.imgPlay:
                    if (falgPause) {
                        mediaplayer.start();
                        falgPause = false;
                    } else
                        playSong(songfile[cListItem]);
                    break;
                case R.id.imgPause:
                        mediaplayer.pause();
                        falgPause=true;
                        break;
                case R.id.imgNext:
                        nextSong();
                    break;
                case R.id.imgEnd:
                        mediaplayer.release();
                        finish();
                    break;
            }

        }

    };
    private AdapterView.OnItemClickListener lstListener=new AdapterView.OnItemClickListener(){
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            cListItem=i;
            playSong(songfile[cListItem]);
        }
    };

    private void playSong(int song) {
        mediaplayer.reset();
        mediaplayer=MediaPlayer.create(MainActivity.this, song); //播放歌曲來源。
        try {
            mediaplayer.prepare();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaplayer.start(); //
        txtMusic.setText("歌曲名稱" + songname[cListItem]); //更新
        mediaplayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            public void onCompletion(MediaPlayer arg0) {
                nextSong(); //
            }
        });//播放下一首
        falgPause=false;
    }
    //      播放下一首
    private void nextSong() {
        cListItem++;
        if (cListItem >= lstMusic.getCount()) //播放下一首，指標加1 。
            cListItem = 0;
        playSong(songfile[cListItem]);
    }
    //  播放上一首
    private void frontSong() {
        cListItem--;
        if (cListItem < 0)
            cListItem = lstMusic.getCount()-1; //播放上一首，指標減1
        playSong(songfile[cListItem]);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgFront= findViewById(R.id.imgFront);
        imgStop= findViewById(R.id.imgStop);
        imgPlay= findViewById(R.id.imgPlay);
        imgPause= findViewById(R.id.imgPause);
        imgNext= findViewById(R.id.imgNext);
        imgEnd= findViewById(R.id.imgEnd);
        lstMusic= findViewById(R.id.lstMusic);
        txtMusic=findViewById(R.id.txtMusic);
        imgFront.setOnClickListener(listener);
        imgStop.setOnClickListener(listener);
        imgPlay.setOnClickListener(listener);
        imgPause.setOnClickListener(listener);
        imgNext.setOnClickListener(listener);
        imgEnd.setOnClickListener(listener);
        lstMusic.setOnItemClickListener(lstListener);
        mediaplayer=new MediaPlayer();
        ArrayAdapter<String> adaSong=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,songname);
        lstMusic.setAdapter(adaSong);

    }


    };





