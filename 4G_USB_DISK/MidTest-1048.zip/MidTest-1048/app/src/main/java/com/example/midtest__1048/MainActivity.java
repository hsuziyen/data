package com.example.midtest__1048;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editTextName;
    private EditText editTextID;
    private TextView textViewClass;
    private RadioGroup radioGroup;
    private RadioButton radioButtonA;
    private RadioButton radioButtonB;
    private Button buttonName;
    private Button buttonID;
    private RadioGroup.OnCheckedChangeListener radioGroupListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkid) {

            RadioButton radChecked = (RadioButton) findViewById(checkid);
            if (checkid == R.id.radioButtonA) {
                textViewClass.setText("我的班級是:" + radioButtonA.getText());
            } else {
                textViewClass.setText("我的班級是:" + radioButtonB.getText());
            }

        }
    };
    private View.OnClickListener buttonIDListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Toast toast=Toast.makeText(MainActivity.this,"我的學號是:"+ editTextID.getText(),Toast.LENGTH_LONG);
            toast.show();
        }
    };
    private View.OnClickListener buttonNameListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            AlertDialog.Builder adb=new AlertDialog.Builder(MainActivity.this);
            adb.setTitle("許芷嫣Andrioid期中考");
            adb.setMessage("輸入的姓名是:"+editTextName.getText());
            adb.show();
        }
    };


    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            editTextName = (EditText) findViewById(R.id.editTextName);
            editTextID = (EditText) findViewById(R.id.editTextID);
            textViewClass = (TextView) findViewById(R.id.textViewClass);
            radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
            radioButtonA = (RadioButton) findViewById(R.id.radioButtonA);
            radioButtonB = (RadioButton) findViewById(R.id.radioButtonB);
            buttonName = (Button) findViewById(R.id.buttonName);
            buttonID = (Button) findViewById(R.id.buttonID);


            radioGroup.setOnCheckedChangeListener(radioGroupListener);

            buttonID.setOnClickListener(buttonIDListener);


            buttonName.setOnClickListener(buttonNameListener);
        }
    }
