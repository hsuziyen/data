package com.example.final1048;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnPhotoPlayer;
    private Button btnMusicPlayer;
    private Button btnVideoPlayer;
    private Button Go2ndPage;
    private View.OnClickListener btnPhotoPlayerListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,PhotoPlayerActivity1048.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btnMusicPlayerListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,MusicPlayerActivity1048.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener btnVideoPlayerListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,VideoPlayerActivity1048.class);
            startActivity(intent);
        }
    };
    private View.OnClickListener Go2ndPageListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,Main2Activity1048.class);
            startActivity(intent);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPhotoPlayer=(Button)findViewById(R.id.btnPhotoPlayer);
        btnMusicPlayer=(Button)findViewById(R.id.btnMusicPlayer);
        btnVideoPlayer=(Button)findViewById(R.id.btnVideoPlayer);
        Go2ndPage=(Button)findViewById(R.id.Go2ndPage);
        btnPhotoPlayer.setOnClickListener(btnPhotoPlayerListener);
        btnMusicPlayer.setOnClickListener(btnMusicPlayerListener);
        btnVideoPlayer.setOnClickListener(btnVideoPlayerListener);
        Go2ndPage.setOnClickListener(Go2ndPageListener);
    }
}
