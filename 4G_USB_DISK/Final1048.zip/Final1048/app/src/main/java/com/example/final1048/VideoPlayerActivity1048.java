package com.example.final1048;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class VideoPlayerActivity1048 extends AppCompatActivity {
    private Button Go1stPage;
    private View.OnClickListener Go1stPageListener=new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(VideoPlayerActivity1048.this,MainActivity.class);
            startActivity(intent);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player1048);
        Go1stPage=(Button)findViewById(R.id.Go1stPage);
        Go1stPage.setOnClickListener(Go1stPageListener);
    }
}
