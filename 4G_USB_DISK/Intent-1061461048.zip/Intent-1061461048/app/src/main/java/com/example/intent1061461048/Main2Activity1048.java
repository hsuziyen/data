package com.example.intent1061461048;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Enumeration;
import java.util.ResourceBundle;

public class Main2Activity1048 extends AppCompatActivity {
    private Button Go1stPage;
    private TextView txtShow;
    private View.OnClickListener Go1stPageListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            Intent intent = new Intent();
            intent.setClass(Main2Activity1048.this, MainActivity.class);
            startActivity(intent);
        }
    };
    private ResourceBundle bundle = new ResourceBundle() {
        @Override
        protected Object handleGetObject(String s) {
            return null;
        }

        @Override
        public Enumeration<String> getKeys() {
            return null;
        }
    };
    private Object Bundle = new Bundle();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main21048);



        Go1stPage=(Button)findViewById(R.id.Go1stPage);
        txtShow=(TextView)findViewById(R.id.txtShow);
        Intent intent=this.getIntent();
        Bundle bundle=intent.getExtras();
        String name=bundle.getString("Name");
        int age=bundle.getInt("Age");
        Double tall=bundle.getDouble("Tall");
        String s="姓名" +name+"\n"+"年齡" +age+"\n"+"身高" +tall;
        txtShow.setText(s);
        Go1stPage.setOnClickListener(Go1stPageListener);
    }
}
