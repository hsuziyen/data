package com.example.intent1061461048;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button Go2ndPage;
    private View.OnClickListener Go2ndPageListener=new View.OnClickListener(){
        @Override
        public void onClick(View view) {

            Intent intent=new Intent();
            intent.setClass(MainActivity.this,Main2Activity1048.class);

            String name="許芷嫣";
            int age=21;
            Double tall=155.5;

            Bundle bundle=new Bundle();
            bundle.putString("Name",name);
            bundle.putInt("Age",age);
            bundle.putDouble("Tall",tall);


            intent.putExtras(bundle);
            startActivity(intent);
        }
    } ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Go2ndPage=(Button)findViewById(R.id.Go2stpage);
        Go2ndPage.setOnClickListener(Go2ndPageListener);
    }
}
