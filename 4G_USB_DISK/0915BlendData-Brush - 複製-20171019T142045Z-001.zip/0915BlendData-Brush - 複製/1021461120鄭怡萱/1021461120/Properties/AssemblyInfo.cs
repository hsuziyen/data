﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 組件的一般相關資訊是透過下列
// 屬性設定來控制。變更這些屬性值，可修改
// 與組件相關聯的資訊。
[assembly: AssemblyTitle("1021461120")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("1021461120")]
[assembly: AssemblyCopyright("Copyright ©  2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 將 ComVisible 設為 false 會導致此組件中的類型不會顯示在
// COM 元件中，如果您需要從 COM 存取此組件中的某個類型，
// 請將該類型的ComVisible 屬性設定為true。
[assembly: ComVisible(false)]

// 如果這個專案可以公開給 COM 使用，則下列的 GUID 即為型別程式庫 (typelib) 的識別碼
[assembly: Guid("ecf5ea6c-6602-4b0f-a4e8-858e4c8c76da")]

// 組件的版本資訊包含下列四個值:
//
//      主要版本
//      次要版本 
//      組建編號
//      修訂
//
// 您可以指定所有的值或預設組建編號和修訂編號，
// 指定的方法是使用 '*'，如下:
// [assembly: AssemblyVersion("1.0.*")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]