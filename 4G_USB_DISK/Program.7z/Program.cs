﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1061461048
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            x = f(2);
            Console.WriteLine("x=" + x);

            double area;
            int x1 = 4, x2 = 4, x3 = 9;
            area = f2(x1, x2, x3);
            if (area == -1)
            {
                Console.WriteLine("not a triangle!!!!!");
            }
            else
                Console.WriteLine("三角形三邊" + x1 + "" + x2 + "" + x3 + "");

            double m = HW4.f3(1000, 24);
            Console.WriteLine(m);
            Console.Read();
        }

        static int f(int y)
        {
            return 2 * y - 3;
        }
        static double f2(int a, int b, int c)
        {
            if (a + b > c && b + c > a && a + c > b)
            {
                double s;
                s = (a + b + c) / 2;
                double w;
                w = s * (s - a) * (s - b) * (s - c);
                w = Math.Sqrt(w);
                return w;
            }
            else
                return -1;
        }

    }
}

