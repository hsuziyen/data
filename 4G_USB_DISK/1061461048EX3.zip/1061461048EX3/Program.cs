﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1061461048EX3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] name = new string[] { "小強", "志明", "春嬌","阿榮","大雄"};
            int[,] vote = new int[5, 3] { {50,60,70},
                {30,40,50 },{70,80,90 },{ 66,77,88},{ 22,33,44} };
            int[] total = new int[name.Length];
            int[] fail = new int[name.Length];
            for (int i = 0; i < vote.GetLength(0); i++)
            {
                for (int j = 0; j < vote.GetLength(1); j++)
                {
                    total[i] += vote[i, j];
                    if (vote[i, j] < 60)
                    {
                        fail[i]++; 
                    }
                }
            }
            Console.WriteLine("姓名\t國文\t英文\t數學\t平均\t不及格科目");
            for (int i = 0; i < vote.GetLength(0); i++)
            {
                Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}",
                    name[i],vote[i,0], vote[i, 1], vote[i, 2], total[i]/3,fail[i]);
            }

        }
    }
}
