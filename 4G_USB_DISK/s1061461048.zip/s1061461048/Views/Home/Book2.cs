﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace s1061461048singer.Controllers//.Partials
{
    [MetadataType(typeof(BookMD))]
    public partial class Book
    {
        public class BookMD
        {
            [Required(ErrorMessage ="ISBN必填")]
            public string ISBN { get; set; }

            [Display(Name ="書名")]
            [Required(ErrorMessage = "書名必填")]
            public string Name { get; set; }

            [Display(Name = "定價")]
            [Remote("CheckPrice","Home",ErrorMessage ="低於成本價")]
            public int Price { get; set; }
        }
    }
}