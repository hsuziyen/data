package com.example.photoplayer1048;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private Button btnPrev,btnNext;
    private ImageView imagePhoto;
    int[]imgId={R.drawable.img01,R.drawable.img02,R.drawable.img03,R.drawable.img04,R.drawable.img05,R.drawable.img06};
    int p=0;
    int count=imgId.length;
    private View.OnClickListener btnPrevListener=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            p--;
            if (p<0)
                p=count-1;
            imagePhoto.setImageResource(imgId[p]);
            setTitle("第"+(p+1) +"/"+count);
        }
    } ;
    private View.OnClickListener btnNextListener=new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            p++;
            if (p==count)
                p=0;
            imagePhoto.setImageResource(imgId[p]);
            setTitle("第"+(p+1) +"/"+count);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPrev=(Button)findViewById(R.id.btnPrev);
        btnNext=(Button)findViewById(R.id.btnNext);
        imagePhoto=(ImageView) findViewById(R.id.imgPhoto);
        btnPrev.setOnClickListener(btnPrevListener);
        btnNext.setOnClickListener(btnNextListener);

    }
}
